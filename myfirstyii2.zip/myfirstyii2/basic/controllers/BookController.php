<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\book;

/**
* 
*/
class BookController extends Controller
{
	
	public function actionList()
	{
		$bookModel = new book();
		return $this->render('list',['bookModel' => $bookModel,]);
	}

	public function actionAdd(){
      $bookModel = new book();
      $bookname = '';
      if($bookModel -> load(Yii::$app->request->post())){
        $bookModel->storeTable(Yii::$app->request->post()['book']);
        return $this->render('list',['bookModel'=>$bookModel]);
      }
      else{
      	return $this->render('add',['bookModel'=>$bookModel,'bookname'=>$bookname]);
      }
    }

    public function actionEdit(){
      $bookModel = book::findOne(Yii::$app->request->get('id'));//get parameter from /edit?id=<param>
      $bookname = '';
      if($bookModel -> load(Yii::$app->request->post())){ //load() match the request from form with the rules
        $bookModel->updateTable(Yii::$app->request->get('id'), Yii::$app->request->post());
        return $this->render('list',['bookModel'=>$bookModel]);
      }
      else{
      	return $this->render('edit',[
      		'bookModel'=>$bookModel, //book model is trannsfer to edit.php
      		'bookname'=>$bookname]);
      }
    }

    public function actionDelete(){
      $bookModel = new book();
      $bookname = '';
      if(Yii::$app->request->get()){
        $bookModel->deleteTable(Yii::$app->request->get('id'));
        return $this->redirect('/book/listBook');
      }
      else{
      	return $this->render('list',['bookModel'=>$bookModel,'bookname'=>$bookname]);
      }
    }

}

?>