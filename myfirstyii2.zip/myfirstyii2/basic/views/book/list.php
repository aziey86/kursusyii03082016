<?php

use yii\helpers\Html;
use yii\helpers\Url;
//use app\models\Book;

$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;;
//$bookModel = new book;

$books = $bookModel->attributeLabels();
?>

<style>
	.magleft5{
		margin-left: 5px;
	}
</style>

<div class="site-about">
   <h1><?= Html::encode($this->title) ?></h1>
   <a class="btn btn-primary" href="<?php echo URL::to('add'); ?>">Add Book</a> 
   <!-- primary=biru, success=hijau, danger=merah, info=kuning -->
   <div style="...">  	
   
		<table class="table table-bordered">
			<tr>
			   <th class="text-center"><?php echo $books['bookname']; ?></th>
		       <th class="text-center"><?php echo $books['publisher']; ?></th>
		       <th class="text-center"><?php echo $books['edition']; ?></th>
		       <th class="text-center"><?php echo $books['author']; ?></th>
		       <th class="text-center"><?php echo $books['price']; ?></th>
		       <th class="text-center"><?php echo $books['isbn']; ?></th>
		       <th class="text-center"><?php echo "Action"; ?></th>
			</tr>

			 <!-- <?php 
			//	foreach ($bookModel->getListUseCommand() as $book) {
		   	//	echo '<tr><td>' . $book['bookname'] . '</td><td>' . $book['publisher'] . '</td><td>' . $book['edition'] . '</td><td>' . $book['author'] . '</td><td>' . $book['price'] . '</td><td>' . $book['isbn'] . '</td></tr>';
			//} ?>   -->

			 <!-- <?php 
				// $listbook = $bookModel->getListUseCommand();
		   		// echo '<tr><td>' . $listbook['bookname'] . '</td><td>' . $listbook['publisher'] . '</td><td>' . $listbook['edition'] . '</td><td>' . $listbook['author'] . '</td><td>' . $listbook['price'] . '</td><td>' . $listbook['isbn'] . '</td></tr>';
			?> -->

			<!-- <?php 
			//	$singleBook  = $bookModel->getListUseCommand();
			 //  	echo '<tr><td colspan="5">' . $singleBook[0] . '</td></tr>';
			?> -->

			<!-- <?php 
			//	$num = $bookModel->getListUseCommand();
		   	//	echo '<tr><td colspan="5">'.$num. '</td></tr>';
			?> -->  

			<?php 
				foreach ($bookModel->getTableList() as $book) {
		   		echo '<tr><td>' . $book['bookname'] . '</td><td>' . $book['publisher'] . '</td>
		   		<td>' . $book['edition'] . '</td><td>' . $book['author'] . '</td>
		   		<td>' . $book['price'] . '</td><td>' . $book['isbn'] . '</td>
		   		<td><a class="btn btn-xs btn-info" href="'.URL::to(['book/edit', 'id'=>$book['id']]).'">Edit</a>
		   		<a class="btn btn-xs btn-danger magleft5"
		   		href="'.URL::to(['book/delete', 'id'=>$book['id']]).'">Delete</a></td>
		   		</tr>';
			} ?>  

		</table>
	</div>
</div>
