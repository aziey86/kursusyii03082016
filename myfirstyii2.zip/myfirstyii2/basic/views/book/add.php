<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

$this->title = 'Book';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="book-add">
   <h1><?= Html::encode($this->title) ?></h1>
   <p>Please fill out the field below:</p>
   <?php $form = ActiveForm::begin([ 'options' => ['class' => 'form-horizontal'],
   'fieldConfig' => [
       'template' => "{label}\n<div class=\"col-lg-3\">{input}{error}</div>",
       'labelOptions' => ['class' => 'col-lg-4 control-label'],
   ]]); ?>
	<?= $form->field($bookModel, 'bookname') ?>
	<?= $form->field($bookModel, 'publisher') ?>
	<?= $form->field($bookModel, 'edition') ?>
	<?= $form->field($bookModel, 'author') ?>
	<?= $form->field($bookModel, 'price') ?>
	<?= $form->field($bookModel, 'isbn') ?>
   
	<label class="col-lg-3"></label>
	<?= Html::submitButton('Save',['class'=>'btn btn-primary']) ?>
	<?= Html::a('Back', Url::to('/book/listBook'), array('class'=>'btn btn-warning magleft10')) ?>
   	<?php ActiveForm::end(); ?>
</div>